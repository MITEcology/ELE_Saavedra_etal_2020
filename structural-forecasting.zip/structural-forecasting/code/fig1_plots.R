# Computes the fraction of LV simulations in which
# each individual species and each combination of species 
# survives and plots the results for a theoretical matrix

# cleaning wd, loading functions and packages ------------------------------
rm(list = ls(all = TRUE))
if(!require(ggplot2)) {install.packages("ggplot2"); library(ggplot2)}
if(!require(dplyr)) {install.packages("dplyr"); library(dplyr)}
if(!require(plyr)) {install.packages("plyr"); library(plyr)}
if(!require(tidyr)) {install.packages("tidyr"); library(tidyr)}
if(!require(viridis)) {install.packages("viridis"); library(viridis)}
if(!require(scales)) {install.packages("scales"); library(scales)}
# whether to save plots
save_plots <- TRUE

# reading results file ------------------------------
mat_name <- "7A"
df_classic <- read.csv(paste("results/tables/predicting_surv_sp_", mat_name, "_r.csv", sep = ""))
df_typeII <- read.csv(paste("results/tables/predicting_surv_sp_", mat_name, "_r_typeII.csv", sep = ""))
df_stochastic <- read.csv(paste("results/tables/predicting_surv_sp_", mat_name, "_r_stochastic.csv", sep = ""))
sp_names <- paste("sp", 1:3, sep = "")

# classic (type I): building summary data frame for plotting ------------------------------
# change combination names
df_classic$surv_sp <- as.character(df_classic$surv_sp)
df_classic$surv_sp[df_classic$surv_sp == "1_2"] <- "1, 2"
df_classic$surv_sp[df_classic$surv_sp == "1_3"] <- "1, 3"
df_classic$surv_sp[df_classic$surv_sp == "2_3"] <- "2, 3"
df_classic$surv_sp[df_classic$surv_sp == "1_2_3"] <- "1, 2, 3"
df_classic$surv_sp <- factor(df_classic$surv_sp, levels = c("1", "2", "3", "1, 2", "1, 3", "2, 3", "1, 2, 3"))
# build data frame with fraction of simulations with each combination
init_cond <- unique(df_classic$init_cond)
sp_counts <- tapply(df_classic$surv_sp, df_classic$init_cond, table)
comb_df <- data.frame(matrix(unlist(sp_counts), nrow = length(sp_counts), byrow = TRUE))
names(comb_df) <- names(sp_counts[[1]])
comb_df <- comb_df / apply(comb_df, 1, sum)
# build data frame for individual species
sp1_df <- comb_df[ , grep("1", names(comb_df))]
sp1_sum_df <- data.frame(sp = "1", frac = apply(sp1_df, 1, sum), init_cond = init_cond)
sp2_df <- comb_df[ , grep("2", names(comb_df))]
sp2_sum_df <- data.frame(sp = "2", frac = apply(sp2_df, 1, sum), init_cond = init_cond)
sp3_df <- comb_df[ , grep("3", names(comb_df))]
sp3_sum_df <- data.frame(sp = "3", frac = apply(sp3_df, 1, sum), init_cond = init_cond)
sp_sum_df_classic <- rbind(sp1_sum_df, sp2_sum_df, sp3_sum_df)
# data frame with all species combinations
comb_df <- gather(comb_df, "surviving_sp")
comb_df$init_cond <- rep(init_cond, length(unique(comb_df$surviving_sp)))
names(comb_df) <- c("surviving_sp", "frac_solutions", "init_cond")
summ_df_classic <- ddply(comb_df, "surviving_sp", summarise,
                         mean_frac = mean(frac_solutions),
                         sd_frac = sd(frac_solutions))

# type II: building summary data frame for plotting ------------------------------
# change combination names
df_typeII$surv_sp <- as.character(df_typeII$surv_sp)
df_typeII$surv_sp[df_typeII$surv_sp == "1_2"] <- "1, 2"
df_typeII$surv_sp[df_typeII$surv_sp == "1_3"] <- "1, 3"
df_typeII$surv_sp[df_typeII$surv_sp == "2_3"] <- "2, 3"
df_typeII$surv_sp[df_typeII$surv_sp == "1_2_3"] <- "1, 2, 3"
df_typeII$surv_sp <- factor(df_typeII$surv_sp, levels = c("1", "2", "3", "1, 2", "1, 3", "2, 3", "1, 2, 3"))
# build data frame with fraction of simulations with each combination
init_cond <- unique(df_typeII$init_cond)
sp_counts <- tapply(df_typeII$surv_sp, df_typeII$init_cond, table)
comb_df <- data.frame(matrix(unlist(sp_counts), nrow = length(sp_counts), byrow = TRUE))
names(comb_df) <- names(sp_counts[[1]])
comb_df <- comb_df / apply(comb_df, 1, sum)
# build data frame for individual species
sp1_df <- comb_df[ , grep("1", names(comb_df))]
sp1_sum_df <- data.frame(sp = "1", frac = apply(sp1_df, 1, sum), init_cond = init_cond)
sp2_df <- comb_df[ , grep("2", names(comb_df))]
sp2_sum_df <- data.frame(sp = "2", frac = apply(sp2_df, 1, sum), init_cond = init_cond)
sp3_df <- comb_df[ , grep("3", names(comb_df))]
sp3_sum_df <- data.frame(sp = "3", frac = apply(sp3_df, 1, sum), init_cond = init_cond)
sp_sum_df_typeII <- rbind(sp1_sum_df, sp2_sum_df, sp3_sum_df)
# data frame with all species combinations
comb_df <- gather(comb_df, "surviving_sp")
comb_df$init_cond <- rep(init_cond, length(unique(comb_df$surviving_sp)))
names(comb_df) <- c("surviving_sp", "frac_solutions", "init_cond")
summ_df_typeII <- ddply(comb_df, "surviving_sp", summarise,
                        mean_frac = mean(frac_solutions),
                        sd_frac = sd(frac_solutions))

# stochastic: building summary data frame for plotting ------------------------------
# change combination names
df_stochastic$surv_sp <- as.character(df_stochastic$surv_sp)
df_stochastic$surv_sp[df_stochastic$surv_sp == "1_2"] <- "1, 2"
df_stochastic$surv_sp[df_stochastic$surv_sp == "1_3"] <- "1, 3"
df_stochastic$surv_sp[df_stochastic$surv_sp == "2_3"] <- "2, 3"
df_stochastic$surv_sp[df_stochastic$surv_sp == "1_2_3"] <- "1, 2, 3"
df_stochastic$surv_sp <- factor(df_stochastic$surv_sp, levels = c("1", "2", "3", "1, 2", "1, 3", "2, 3", "1, 2, 3"))
# build data frame with fraction of simulations with each combination
init_cond <- unique(df_stochastic$init_cond)
sp_counts <- tapply(df_stochastic$surv_sp, df_stochastic$init_cond, table)
comb_df <- data.frame(matrix(unlist(sp_counts), nrow = length(sp_counts), byrow = TRUE))
names(comb_df) <- names(sp_counts[[1]])
comb_df <- comb_df / apply(comb_df, 1, sum)
# build data frame for individual species
sp1_df <- comb_df[ , grep("1", names(comb_df))]
sp1_sum_df <- data.frame(sp = "1", frac = apply(sp1_df, 1, sum), init_cond = init_cond)
sp2_df <- comb_df[ , grep("2", names(comb_df))]
sp2_sum_df <- data.frame(sp = "2", frac = apply(sp2_df, 1, sum), init_cond = init_cond)
sp3_df <- comb_df[ , grep("3", names(comb_df))]
sp3_sum_df <- data.frame(sp = "3", frac = apply(sp3_df, 1, sum), init_cond = init_cond)
sp_sum_df_stochastic <- rbind(sp1_sum_df, sp2_sum_df, sp3_sum_df)
# data frame with all species combinations
comb_df <- gather(comb_df, "surviving_sp")
comb_df$init_cond <- rep(init_cond, length(unique(comb_df$surviving_sp)))
names(comb_df) <- c("surviving_sp", "frac_solutions", "init_cond")
summ_df_stochastic <- ddply(comb_df, "surviving_sp", summarise,
                            mean_frac = mean(frac_solutions),
                            sd_frac = sd(frac_solutions))

# build full data frame with all types of dynamics ------------------------------
sp_sum_df <- rbind(sp_sum_df_classic, sp_sum_df_typeII, sp_sum_df_stochastic)
sp_sum_df$dynamics <- rep(c("Classic (Type I)", "Type II", "Stochastic"), each = nrow(sp_sum_df_classic))

# plot probabilities for each individual species ------------------------------
# creating data frame with analytical probabilities
if (mat_name == "7A") {
  analytical_df <- data.frame(sp = factor(c("1", "2", "3")), 
                              analytical_frac = c(0.6286597, 0.5194796, 0.6056542))
}
if (mat_name == "7B") {
  analytical_df <- data.frame(sp = factor(c("1", "2", "3")), 
                              analytical_frac = c(0.7644364, 0.2889095, 0.9231101))
}
if (mat_name == "7C") {
  analytical_df <- data.frame(sp = factor(c("1", "2", "3")), 
                              analytical_frac = c(0.4204878, 0.9423175, 0.4138142))
}
# plot
pal_fill <- c("#F781BF", "#000000")
sp_sum_df$dynamics <- factor(sp_sum_df$dynamics, 
                             levels = c("Classic (Type I)", "Type II", "Stochastic"))
fig_E <- ggplot() +
  geom_boxplot(data = sp_sum_df, aes(x = sp, y = frac), 
               size = 0.6, color = "#000000", outlier.size = 1, show.legend = FALSE) +
  geom_point(data = sp_sum_df, aes(x = sp, y = frac, fill = "simulation"), size = 0) +
  geom_point(data = analytical_df, aes(x = sp, y = analytical_frac, fill = "analytical"), 
             shape = 23, size = 3) +
  facet_wrap(~ dynamics, ncol = 3) +
  scale_fill_manual(values = pal_fill) +
  scale_y_continuous(limits = c(0, 1)) +
  xlab("Species") +
  ylab("Probability of persistence") +
  guides(color = guide_legend(override.aes = list(size = 3.5, shape = 22)),
         fill = guide_legend(override.aes = list(size = 3.5, shape = 22))) +
  theme_bw() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_rect(color = "black", fill = NA, size = 1),
        axis.text.y = element_text(size = 14),
        axis.title = element_text(size = 18),
        axis.text.x = element_text(size = 14),
        strip.text.x = element_text(size = 18, face = "bold"),
        strip.text.y = element_text(size = 18, face = "bold"),
        strip.background = element_blank(),
        legend.background = element_rect(color = NA, fill = NA),
        legend.title = element_blank(),
        legend.text = element_text(size = 14),
        legend.key.size = unit(0.5, "cm"),
        legend.position = c(0.89, 0.91))
# save plot
if (save_plots) {
  ggsave(paste("results/figs/fig1_E_", mat_name, ".pdf", sep = ""),
         fig_E, width = 17, height = 9, units = "cm")
}

# plot example for one initial condition ------------------------------
# load ggtern
if(!require(ggtern)) {install.packages("ggtern"); library(ggtern)}
# creating palette
pal_set1 <- c("#E41A1C", "#377EB8", "#FFFF33", "#984EA3", "#FF7F00", "#4DAF4A", "#A65628")
# using just one initial condition
single_init_cond <- 1
# data frame for the single initial condition
df_classic_init_cond <- subset(df_classic, init_cond == single_init_cond)
# plot
fig_A <- ggtern(data = df_classic_init_cond, 
                aes(x = r2, y = r3, z = r1, color = surv_sp)) + 
  geom_point(size = 1) +
  scale_color_manual(values = pal_set1, name = "Observed\nensemble") +
  theme_classic() + 
  guides(color = guide_legend(override.aes = list(size = 3))) +
  labs(x = "sp 2", y = "sp 3", z = "sp 1") +
  theme_nolabels() +
  theme_noticks() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_rect(color = "black", fill = NA, size = 1),
        axis.text.y = element_text(size = 14),
        axis.title = element_text(size = 18),
        axis.text.x = element_text(size = 14),
        legend.position = "none")
# save plot
if (save_plots) {
  ggsave(paste("results/figs/fig1_A_", mat_name, ".pdf", sep = ""),
         fig_A, width = 13, height = 13, units = "cm")
}

# pie plots: proportions of ensembles for each species ------------------------------
# fraction of simulations in which each combination is observed (one initial condition)
summ_df_classic_init_cond <- data.frame(frac = as.numeric(table(df_classic_init_cond$surv_sp) / nrow(df_classic_init_cond)),
                                        surviving_sp = names(table(df_classic_init_cond$surv_sp)))
# change factor level order 
summ_df_classic_init_cond$surviving_sp <- factor(summ_df_classic_init_cond$surviving_sp, 
                                                 levels = c("1", "2", "3", "1, 2", "1, 3", "2, 3", "1, 2, 3"))
# pie plot for species 1
pal1 <- c("#E41A1C", "#FFFFFF", "#FFFFFF", "#984EA3", "#FF7F00", "#FFFFFF", "#A65628")
fig_B <- ggplot(summ_df_classic_init_cond, aes(x = "", y = frac, fill = surviving_sp)) +
  geom_bar(width = 1, stat = "identity", color = "black", size = 0.8) +
  coord_polar("y", start = 0) +
  scale_fill_manual(values = pal1, name = "Observed\nensembles\ncontaining\nspecies 1") +
  theme_minimal() +
  theme(axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.x = element_blank(),
        panel.border = element_blank(),
        panel.grid = element_blank(),
        axis.ticks = element_blank(),
        legend.position = "none")
# save plot
if (save_plots) {
  ggsave(paste("results/figs/fig1_B_", mat_name, ".pdf", sep = ""),
         fig_B, width = 13, height = 13, units = "cm")
}
# pie plot for species 2
pal2 <- c("#FFFFFF", "#377EB8", "#FFFFFF", "#984EA3", "#FFFFFF", "#4DAF4A", "#A65628")
fig_C <- ggplot(summ_df_classic_init_cond, aes(x = "", y = frac, fill = surviving_sp)) +
  geom_bar(width = 1, stat = "identity", color = "black", size = 0.8) +
  coord_polar("y", start = 0) +
  scale_fill_manual(values = pal2, name = "Observed\nensembles\ncontaining\nspecies 2") +
  theme_minimal() +
  theme(axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.x = element_blank(),
        panel.border = element_blank(),
        panel.grid = element_blank(),
        axis.ticks = element_blank(),
        legend.position = "none")
# save plot
if (save_plots) {
  ggsave(paste("results/figs/fig1_C_", mat_name, ".pdf", sep = ""),
         fig_C, width = 13, height = 13, units = "cm")
}
# pie plot for species 3
pal3 <- c("#FFFFFF", "#FFFFFF", "#FFFF33", "#FFFFFF", "#FF7F00", "#4DAF4A", "#A65628")
fig_D <- ggplot(summ_df_classic_init_cond, aes(x = "", y = frac, fill = surviving_sp)) +
  geom_bar(width = 1, stat = "identity", color = "black", size = 0.8) +
  coord_polar("y", start = 0) +
  scale_fill_manual(values = pal3, name = "Observed\nensembles\ncontaining\nspecies 3") +
  theme_minimal() +
  theme(axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.text.x = element_blank(),
        panel.border = element_blank(),
        panel.grid = element_blank(),
        axis.ticks = element_blank(),
        legend.position = "none")
# save plot
if (save_plots) {
  ggsave(paste("results/figs/fig1_D_", mat_name, ".pdf", sep = ""),
         fig_D, width = 13, height = 13, units = "cm")
}
