if(!require(tidyverse)) {install.packages("tidyverse"); library(tidyverse)}
if(!require(tidylog)) {install.packages("tidylog"); library(tidylog)}
if(!require(mvtnorm)) {install.packages("mvtnorm"); library(mvtnorm)}
if(!require(DiagrammeR)) {install.packages("DiagrammeR"); library(DiagrammeR)}
if(!require(cowplot)) {install.packages("cowplot"); library(cowplot)}
if(!require(RColorBrewer)) {install.packages("RColorBrewer"); library(RColorBrewer)}
if(!require(xtable)) {install.packages("xtable"); library(xtable)}


# Samples m vectors randomly on the positive orthant of a n-dimensional unit sphere
c_sphere_sampling <- function(m) {
  r <- abs(rnorm(m))
  d <- sqrt(sum(r^2))
  r <- r/d
  return(r)
}


# calculating omega ------------------------------------------------------
Omega <- function(alpha) {
  S <- nrow(alpha)
  Sigma <- solve(t(alpha) %*% alpha)
  m <- matrix(0, S, 1)
  a <- matrix(0, S, 1)
  b <- matrix(Inf, S, 1)
  d <- pmvnorm(lower = rep(0, S), upper = rep(Inf, S), mean = rep(0, S), sigma = Sigma)
  
  d[1]^(1/S)*2
}

which.maxn <- function(x,n=1){
  if (n==1)
    which.max(x)
  else
  {
    if (n>1){
      ii <- order(x,decreasing=TRUE)[1:min(n,length(x))]
      ii[!is.na(x[ii])]
    }
    else {
      stop("n must be >=1")
    }
  }
}

#' @export
which.minn <- function(x,n=1){
  if (n==1)
    which.min(x)
  else
  {
    if (n>1){
      ii <- order(x,decreasing=FALSE)[1:min(n,length(x))]
      ii[!is.na(x[ii])]
    }
    else {
      stop("n must be >=1")
    }
  }
}