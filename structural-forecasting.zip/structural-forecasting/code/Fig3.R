### This is the source code needed to reproduce Figure 3
source("toolbox.r")
if(!require(deSolve)) {install.packages("deSolve"); library(deSolve)}
if(!require(matrixcalc)) {install.packages("matrixcalc"); library(matrixcalc)}

### These are the 8 experimental outcomes from 3-species competition communities reported in the SI of Friedman et al. (2017). The order here is presented 
### starting from species Ea, Pa, Pch, Pci, Pf, Pp, Pv, and Sm. 
observations <- c(1,1,0,1,1,0,1,0,1,1,1,0,1,1,0,1,1,0,0,1,0,1,1,1) %>%
  matrix(nrow=8,ncol = 3, byrow=TRUE)
#SS <- nrow(observations)

### This is the 8-species interaction matrix reported in the SI of Friedman et al. (2017). Note that this matrix is given in the K-formalism
alpha8 <- c(1,0.69,1.09,0.55,1.53,0.82,1.09,0.72,-0.18,1,2.44,-2.58,1.13,0.43,0.01,0.21,-0.11,-0.8,1,-15.75,0.29,-0.04,-0.05,-0.03,-0.32,0,0.18,1,-3.39,0,0.05,-0.3,-0.02,0.28,1.2,0.83,1,0.01,0.07,-0.1,0.87,1.58,1.24,0.24,1,1,1.01,0.84,0.83,0.28,0.47,0,-0.02,0.79,1,0.7,0.96,1.23,1.42,1.21,1.31,0.91,0.98,1) %>%
  matrix(ncol = 8) %>%
  t()
rownames(alpha8) <- c("Ea", "Pa", "Pch", "Pci", "Pf", "Pp", "Pv", "Sm")
colnames(alpha8) <- c("Ea", "Pa", "Pch", "Pci", "Pf", "Pp", "Pv", "Sm")
S8 <- nrow(alpha8)

S <- 3 ### This is the number of species we are interested in having in the community
total <- 0 ### counter for accuracy of predictions
singular <- rep(0,56) ## to check if a reduced matrix is singular
q <- combn(1:S8,3)  ### combinations
nexp <- 0 ### to filter competition matrices only
for(r in 1:56){  ### let's look throught the 56 combinations of 3-species communities, select those competition systems, and predict their outcome
  index3 <- q[,r]
  alpha3 <- alpha8[index3,index3] ### new matrix for 3-species communities
  neg <- which(alpha3<0)
  if ((length(neg)==0)&&(r!=21)){ ### use only competition systems and discard combination 21 which is singular
    nexp <- nexp + 1
    probs <- 0
    c <- 0
    tot <- S-1
  
    for(i in 1:tot){
      s <- combn(1:S,S-i+1)
      for (j in 1:ncol(s)){
        c <- c + 1
        index <- s[,j]
        M <- matrix(0,S,S)
        M[index,index] <- alpha3[index,index]
        diag(M) <- 1
        probs[c] <- (Omega(M)/1)^(S) ### Omega

        for (k in 1:length(index)){
          c <- c + 1
          M2 <- M
          M2[index[k],index[k]] <- 0
          sing <- is.singular.matrix(M2)
          if (sing==TRUE) {
            singular[r] <- 1
            M2 <- M[-index[k],-index[k]]
            probs[c] <- (Omega(M2)/1)^(2)
          }
          if (sing==FALSE) {
            probs[c] <- (Omega(M2)/1)^(S) ### Omega
          }
        }
        
      }
    }
  
    probs[7] <- 1 - probs[5] - probs[6]
    probs[10] <- 1 - probs[8] - probs[9]
    probs[13] <- 1 - probs[11] - probs[12]
    b <- c(probs[1]+probs[5]+probs[8]+probs[7],probs[1]+probs[5]+probs[11]+probs[6],probs[1]+probs[8]+probs[11]+probs[9],1-probs[1]-probs[5]-probs[8]-probs[7]-probs[11]-probs[6]-probs[9])
    A <- c(1,probs[8],probs[5]+probs[7],0,probs[11],1,probs[5]+probs[6],0,probs[11],probs[8]+probs[9],1,0,-probs[11],-probs[8]-probs[9],-probs[5]-probs[7]-probs[6],1) %>%
      matrix(ncol = 4) %>%
      t()

    survival <- solve(A,b)  # obtain the probabilities of species persistence
    present <- ((survival[-4])>=probs[1]^(1/3))*1 ### check if those probabilities are greater than the threshold of average Omega. If yes, then species survives
    accuracy <- (sum(present==observations[nexp,])*1) ##check predictions with observations

    print(alpha3) ### matrix
    print(c(observations[nexp,])) ###observations
    print(c(survival[-4],probs[1]^(1/3))) # species probabilites - the last one corresponds to the threshold
    total <- total + accuracy ### check the accuracy (fraction of good predicitons over the number of predictions)
  }
}
print(total/(3*nexp)) ### this is the total accuracy over the 8 communities


