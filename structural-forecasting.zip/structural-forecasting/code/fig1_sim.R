# Simulates Lotka-Volterra dynamics for multiple 
# environments and initial conditions and records the
# identities of surviving species

# cleaning and setting wd, loading functions and packages ------------------------------
rm(list = ls(all = TRUE))
if(!require(deSolve)) {install.packages("deSolve"); library(deSolve)}
if(!require(diffeqr)) {install.packages("diffeqr"); library(diffeqr)}
if(!require(JuliaCall)) {install.packages("JuliaCall"); library(JuliaCall)}
julia_setup(JULIA_HOME = "/Applications/Julia-1.3.app/Contents/Resources/julia/bin")
options(JULIA_HOME = "/Applications/Julia-1.3.app/Contents/Resources/julia/")
diffeq_setup()
source("code/functions/lotka_volterra.R")
source("code/functions/lv_pruning.R")
source("code/functions/simplex_sampling.R")

# reading interaction matrix file ------------------------------
mat_name <- "7A" # Different matrics can be used. The folder data provides a set of matrices.
A <- as.matrix(read.table(paste("data/comp_matrices/", mat_name, ".txt", sep = "")))
# extracting number of species
n_sp <- nrow(A)
rownames(A) <- paste("sp", 1:n_sp, sep = "")
colnames(A) <- paste("sp", 1:n_sp, sep = "")

# setting simulation parameters ------------------------------
# number of initial conditions
init_cond <- 100
# sampling initial conditions randomly
N <- replicate(init_cond, runif(n_sp, 0, 1), simplify = FALSE)
# number of simulations
n_sim <- 2000
# time steps
times <- seq(0, 200, 0.01)
# choose formalism
formalism <- "r" # other options are K (for K-formalism), "r_typeII, r_stochastic 

# performing simulations ------------------------------
df <- data.frame()
for (i in 1:init_cond) {
  print(i)
  # sample r vectors on the simplex
  r <- simplex_sampling(n_sim, n_sp)
  # run simulations and extract surviving species
  surv_sp <- mapply(lv_pruning, r,
                    MoreArgs = list(A = A, N = N[[i]], times = times, 
                                    formalism = formalism, extinct_tol = 0.0001), 
                    SIMPLIFY = FALSE)
  # build data frame with results
  r_df <- data.frame(matrix(unlist(r), nrow = length(r), byrow = TRUE))
  names(r_df) <- paste("r", 1:nrow(A), sep = "")
  N_df <- as.data.frame(matrix(rep(N[[i]], each = nrow(r_df)), ncol = nrow(A)))
  names(N_df) <- colnames(A)
  curr_df <- cbind(r_df, N_df)
  curr_df$init_cond <- i
  curr_df$surv_sp <- unlist(surv_sp)
  # merge with larger data frame
  df <- rbind(df, curr_df)
}

# save results ------------------------------
write.csv(df, paste("results/tables/predicting_surv_sp_", mat_name, 
                    "_", formalism, ".csv", sep = ""), 
          row.names = FALSE)
