### This is the source code needed to reproduce Figure 4
source("toolbox.r")
if(!require(deSolve)) {install.packages("deSolve"); library(deSolve)}
if(!require(matrixcalc)) {install.packages("matrixcalc"); library(matrixcalc)}

### This is the 8-species interaction matrix reported in the SI of Friedman et al. (2017). Note that this matrix is given in the K-formalism
alpha8 <- c(1,0.69,1.09,0.55,1.53,0.82,1.09,0.72,-0.18,1,2.44,-2.58,1.13,0.43,0.01,0.21,-0.11,-0.8,1,-15.75,0.29,-0.04,-0.05,-0.03,-0.32,0,0.18,1,-3.39,0,0.05,-0.3,-0.02,0.28,1.2,0.83,1,0.01,0.07,-0.1,0.87,1.58,1.24,0.24,1,1,1.01,0.84,0.83,0.28,0.47,0,-0.02,0.79,1,0.7,0.96,1.23,1.42,1.21,1.31,0.91,0.98,1) %>%
  matrix(ncol = 8) %>%
  t()
rownames(alpha8) <- c("Ea", "Pa", "Pch", "Pci", "Pf", "Pp", "Pv", "Sm")
colnames(alpha8) <- c("Ea", "Pa", "Pch", "Pci", "Pf", "Pp", "Pv", "Sm")
S8 <- nrow(alpha8)
observations8 <- c(0,0,1,0,1,0,1,0) %>% ### This is the outcome of the 8-species community as reported by Friedman et al. (2017)
  matrix(nrow=1,ncol = 8, byrow=TRUE) #%>%

S <- 8 ### This is the number of species we are interested in having in the community
q <- combn(1:S8,S)  ### combinations
index <- q[,1]
alpha <- alpha8[index,index]
survival <- rep(0,S)
sims <- 2500  ### number of simualtions to obtain the probabilities of species persistence. In the text we used 100,000
for(y in 1:sims){
  delta_t <- 0.01 #time step
  time_step <- seq(0,300,by=delta_t)
  N0 <- rep(1,S) #initial conditions for species abundances
  N0 <- N0 / sum(N0)
  gr <- runif(S) # initial coniditons for intrinsic growth rates
  gr <- gr /sum(gr)
  K <- c_sphere_sampling(S) ### sampling random K's in the positive orthant of the unit sphere
  parms <- list(gr=gr, K=K, alpha = alpha) ##ODE
  model <- function(t,N,parms){ dN <- (N * parms$gr / parms$K) * (parms$K - parms$alpha %*% N); list(dN)}
  sol <- ode(N0,time_step,model,parms)
  for(z in 1:S){
    survival[z] <- survival[z] + (sol[nrow(sol),z+1]>0.000001)*1 ### check if the species survived in the simulation
  }
}
survival <- survival / sims ### calculate probabilities
om <- 0
for(h in 1:100){
om <- om + Omega(alpha) ### the threshold Omega the loop deals with numerical instabilities
}
om <- om/100
present <- ((survival)>=om)*1 ### check if those probabilities are greater than the threshold of average Omega. If yes, then species survives
accuracy <- (sum(present==observations8[1,])*1)  ##check predictions with observations
print(alpha) ### matrix
print(c(observations8[1,])) ###observations
print(c(survival,om,accuracy/8)) ### species probabilities, threshold, and accuracy