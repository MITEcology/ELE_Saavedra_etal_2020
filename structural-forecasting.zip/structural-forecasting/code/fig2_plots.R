# Script that plots the species combinations obtained by
# simulating the LV model with the empirical parameters
# for 8 competition systems

# cleaning wd, loading functions and packages ------------------------------
rm(list = ls(all = TRUE))
if(!require(ggplot2)) {install.packages("ggplot2"); library(ggplot2)}
if(!require(ggtern)) {install.packages("ggtern"); library(ggtern)}
if(!require(dplyr)) {install.packages("dplyr"); library(dplyr)}
if(!require(plyr)) {install.packages("plyr"); library(plyr)}
if(!require(tidyr)) {install.packages("tidyr"); library(tidyr)}
if(!require(viridis)) {install.packages("viridis"); library(viridis)}
if(!require(scales)) {install.packages("scales"); library(scales)}
# whether to save plots
save_plots <- TRUE

# reading results file ------------------------------
mat_name <- "friedman2017_Pp_Pv_Sm"
df <- read.csv(paste("results/tables/predicting_surv_sp_", mat_name, "_r.csv", sep = ""))
df_emp_param <- read.csv(paste("results/tables/predicting_surv_sp_empirical_parameters_", 
                               mat_name, ".csv", sep = ""))
sp_names <- strsplit(mat_name, "_", fixed = TRUE)[[1]][2:4]
# change combination names
df$surv_sp <- as.character(df$surv_sp)
df$surv_sp[df$surv_sp == "1"] <- sp_names[1]
df$surv_sp[df$surv_sp == "2"] <- sp_names[2]
df$surv_sp[df$surv_sp == "3"] <- sp_names[3]
df$surv_sp[df$surv_sp == "1_2"] <- paste(sp_names[c(1, 2)], collapse = ", ")
df$surv_sp[df$surv_sp == "1_3"] <- paste(sp_names[c(1, 3)], collapse = ", ")
df$surv_sp[df$surv_sp == "2_3"] <- paste(sp_names[c(2, 3)], collapse = ", ")
df$surv_sp[df$surv_sp == "1_2_3"] <- paste(sp_names[c(1, 2, 3)], collapse = ", ")
df$surv_sp <- factor(df$surv_sp, levels = c(sp_names[1], sp_names[2], sp_names[3], 
                                            paste(sp_names[c(1, 2)], collapse = ", "), 
                                            paste(sp_names[c(1, 3)], collapse = ", "),
                                            paste(sp_names[c(2, 3)], collapse = ", "),
                                            paste(sp_names[c(1, 2, 3)], collapse = ", ")))
df$surv_sp <- droplevels(df$surv_sp)
df_emp_param$surv_sp <- as.character(df_emp_param$surv_sp)
df_emp_param$surv_sp[df_emp_param$surv_sp == "1"] <- sp_names[1]
df_emp_param$surv_sp[df_emp_param$surv_sp == "2"] <- sp_names[2]
df_emp_param$surv_sp[df_emp_param$surv_sp == "3"] <- sp_names[3]
df_emp_param$surv_sp[df_emp_param$surv_sp == "1_2"] <- paste(sp_names[c(1, 2)], collapse = ", ")
df_emp_param$surv_sp[df_emp_param$surv_sp == "1_3"] <- paste(sp_names[c(1, 3)], collapse = ", ")
df_emp_param$surv_sp[df_emp_param$surv_sp == "2_3"] <- paste(sp_names[c(2, 3)], collapse = ", ")
df_emp_param$surv_sp[df_emp_param$surv_sp == "1_2_3"] <- paste(sp_names[c(1, 2, 3)], collapse = ", ")
df_emp_param$surv_sp <- factor(df_emp_param$surv_sp, levels = c(sp_names[1], sp_names[2], sp_names[3], 
                                            paste(sp_names[c(1, 2)], collapse = ", "), 
                                            paste(sp_names[c(1, 3)], collapse = ", "),
                                            paste(sp_names[c(2, 3)], collapse = ", "),
                                            paste(sp_names[c(1, 2, 3)], collapse = ", ")))
df_emp_param$surv_sp <- droplevels(df_emp_param$surv_sp)
# computing fraction of each combination 
table(df_emp_param$surv_sp)

# building k vector ------------------------------
k <- c(0.13, 0.07, 0.11, 0.01, 0.05, 0.14, 0.11, 0.15)
names(k) <- c("Ea", "Pa", "Pch", "Pci", "Pf", "Pp", "Pv", "Sm")
k <- k[sp_names]
k <- k / sum(k)

# building summary data frame for plotting ------------------------------
init_cond <- unique(df$init_cond)
sp_counts <- tapply(df$surv_sp, df$init_cond, table)
comb_df <- data.frame(matrix(unlist(sp_counts), nrow = length(sp_counts), byrow = TRUE))
names(comb_df) <- names(sp_counts[[1]])
comb_df <- comb_df / apply(comb_df, 1, sum)
# data for individual species
sp1_df <- comb_df[ , grep(sp_names[1], names(comb_df))]
sp1_sum_df <- data.frame(sp = sp_names[1], frac = apply(sp1_df, 1, sum), init_cond = init_cond)
sp1_mean <- mean(apply(sp1_df, 1, sum))
sp1_sd <- sd(apply(sp1_df, 1, sum))
sp2_df <- comb_df[ , grep(sp_names[2], names(comb_df))]
sp2_sum_df <- data.frame(sp = sp_names[2], frac = apply(sp2_df, 1, sum), init_cond = init_cond)
sp2_mean <- mean(apply(sp2_df, 1, sum))
sp2_sd <- sd(apply(sp2_df, 1, sum))
sp3_df <- comb_df[ , grep(sp_names[3], names(comb_df))]
sp3_sum_df <- data.frame(sp = sp_names[3], frac = apply(sp3_df, 1, sum), init_cond = init_cond)
sp3_mean <- mean(apply(sp3_df, 1, sum))
sp3_sd <- sd(apply(sp3_df, 1, sum))
summ_sp_df <- data.frame(surviving_sp = sp_names,
                         mean_frac = c(sp1_mean, sp2_mean, sp3_mean),
                         sd_frac = c(sp1_sd, sp2_sd, sp3_sd))
# data for species combinations
comb_df <- gather(comb_df, "surviving_sp")
comb_df$init_cond <- rep(init_cond, length(unique(comb_df$surviving_sp)))
names(comb_df) <- c("surviving_sp", "frac_solutions", "init_cond")
summ_df <- ddply(comb_df, "surviving_sp", summarise,
                 mean_frac = mean(frac_solutions),
                 sd_frac = sd(frac_solutions))

# species combinations using empirical carrying capacities ------------------------------
summ_df_emp_param <- as.data.frame(table(df_emp_param$surv_sp))
names(summ_df_emp_param) <- c("comb", "freq")
summ_df_emp_param$freq <- summ_df_emp_param$freq / sum(summ_df_emp_param$freq)

# plot example for one initial condition ------------------------------
# creating palette
pal_set1 <- c("#E41A1C", "#377EB8", "#FFFF33", "#984EA3", "#FF7F00", "#4DAF4A", "#A65628")
pal_names <- c(sp_names[1], sp_names[2], sp_names[3], 
               paste(sp_names[c(1, 2)], collapse = ", "),
               paste(sp_names[c(1, 3)], collapse = ", "),
               paste(sp_names[c(2, 3)], collapse = ", "),
               paste(sp_names[c(1, 2, 3)], collapse = ", "))
pal_set1 <- pal_set1[match(as.character(levels(df$surv_sp)), pal_names)]
# using just one initial condition
single_init_cond <- 1
# building data frame with k values
k_df <- data.frame(k1 = k[1], k2 = k[2], k3 = k[3])
# plot
fig <- ggtern(data = subset(df, init_cond == single_init_cond), 
              aes(x = r2, y = r3, z = r1, color = surv_sp)) + 
  geom_point(size = 1) +
  geom_point(data = k_df, aes(x = k2, y = k3, z = k1), fill = "black", 
             color = "black", size = 4.5, shape = 23) +
  scale_color_manual(values = pal_set1, name = "Observed\nensemble") +
  theme_classic() + 
  guides(color = guide_legend(override.aes = list(size = 3))) +
  labs(x = sp_names[2], y = sp_names[3], z = sp_names[1]) +
  theme_nolabels() +
  theme_noticks() +
  theme(panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_rect(colour = "black", fill = NA, size = 1),
        axis.text.y = element_text(size = 18),
        axis.title = element_text(size = 22),
        axis.text.x = element_text(size = 18),
        legend.position = "none")
# save plot
if (save_plots) {
  ggsave(paste("results/figs/fig2_", mat_name, ".pdf", sep = ""),
         fig, width = 13, height = 13, units = "cm")
}
