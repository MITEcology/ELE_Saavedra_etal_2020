# Solves the system of ordinary differential equations
# given by the generalized Lotka-Volterra dynamics and
# returns the surviving species at equilibrium
lv_pruning <- function(N, r, K, A, times, formalism, extinct_tol = 0.00000001) {
  out <- lotka_volterra(N, r, K, A, times, formalism)
  eq <- out[nrow(out), -1]
  which_surv_sp <- as.numeric(which(eq > extinct_tol))
  return(paste(which_surv_sp, collapse = "_"))
}