# Script that simulates Lotka-Volterra dynamics for a single 
# environment and many initial conditions and records the
# identities of surviving species

# cleaning and setting wd, loading functions and packages ------------------------------
rm(list = ls(all = TRUE))
if(!require(deSolve)) {install.packages("deSolve"); library(deSolve)}
if(!require(diffeqr)) {install.packages("diffeqr"); library(diffeqr)}
if(!require(JuliaCall)) {install.packages("JuliaCall"); library(JuliaCall)}
julia_setup(JULIA_HOME = "/Applications/Julia-1.3.app/Contents/Resources/julia/bin")
options(JULIA_HOME = "/Applications/Julia-1.3.app/Contents/Resources/julia/")
diffeq_setup()
source("code/functions/lotka_volterra.R")
source("code/functions/lv_pruning.R")
source("code/functions/simplex_sampling.R")

# reading interaction matrix file ------------------------------
mat_name <- "friedman2017_Pci_Pp_Pv"  # Different matrics can be used. The folder data provides a set of matrices.
file_name <- paste(mat_name, ".txt", sep = "")
A <- as.matrix(read.table(paste("data/comp_matrices/", file_name, sep = "")))
# extracting number of species
sp_names <- strsplit(mat_name, "_", fixed = TRUE)[[1]][2:4]
n_sp <- nrow(A)
rownames(A) <- sp_names
colnames(A) <- sp_names

# building r and k vectors ------------------------------
r <- c(0.46, 0.55, 0.18, 0.16, 0.25, 0.65, 0.57, 0.34)
k <- c(0.13, 0.07, 0.11, 0.01, 0.05, 0.14, 0.11, 0.15)
names(r) <- c("Ea", "Pa", "Pch", "Pci", "Pf", "Pp", "Pv", "Sm")
names(k) <- c("Ea", "Pa", "Pch", "Pci", "Pf", "Pp", "Pv", "Sm")
r <- r[sp_names]
r <- r / sum(r)
k <- k[sp_names]
k <- k / sum(k)

# setting simulation parameters ------------------------------
# number of initial conditions
init_cond <- 100
# sampling initial conditions randomly
N <- replicate(init_cond, runif(n_sp, 0, 1), simplify = FALSE)
# time steps
times <- seq(0, 200, 0.01)

# performing simulations ------------------------------
df <- data.frame()
for (i in 1:init_cond) {
  print(i)
  # run simulation and extract surviving species
  surv_sp <- lv_pruning(N = N[[i]], r = r, K = k, A = A, times = times, 
                        formalism = "K", extinct_tol = 0.0001)  # other options are K (for K-formalism), "r_typeII, r_stochastic 
  # build data frame with results
  curr_df <- as.data.frame(matrix(N[[i]], ncol = nrow(A)))
  names(curr_df) <- colnames(A)
  curr_df$init_cond <- i
  curr_df$surv_sp <- surv_sp
  # merge with larger data frame
  df <- rbind(df, curr_df)
}

# save results ------------------------------
write.csv(df, paste("results/tables/predicting_surv_sp_empirical_parameters_", mat_name,  ".csv", sep = ""), 
          row.names = FALSE)
